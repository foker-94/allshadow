<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class Forms extends Component
{
    public function render()
    {
        return view('components.forms');
    }
}
