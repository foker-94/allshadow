{{--<x-layouts.base>--}}

{{--    @extends('roles.layout')--}}

{{--    @extends('layouts/sidenav')--}}


{{--</x-layouts.base>--}}

<x-layouts.base>


    {{--    @if(in_array(request()->route()->getName(), ['dashboard', 'profile', 'profile-example', 'roles', 'bootstrap-tables', 'transactions',--}}
    {{--    'buttons',--}}
    {{--    'forms', 'modals', 'notifications', 'typography', 'upgrade-to-pro']))--}}

    {{-- Nav --}}
    @include('layouts.nav')
    {{-- SideNav --}}
    @include('layouts.sidenav')
    <main class="content">
        {{-- TopBar --}}
        @include('layouts.topbar')

        <div class="row fa-pull-left ml-4">
            <div class="col-md-6 ext-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            <div class="col-md-6 ext-center">
                <a class="btn btn-primary" href="{{ route('roles.index') }}"> Back</a>
            </div>
        </div>

        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="container mt-5">
            <form action="{{ route('roles.store') }}" method="POST">
                @csrf

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-8">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Nom:</strong>
                                    <input type="text" name="name" class="form-control" placeholder="Fongan kom">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Description:</strong>
                                    <textarea class="form-control" style="height:150px" name="description"
                                              placeholder="Detail"></textarea>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </form>
        </div>
        {{-- Footer --}}
        @include('layouts.footer')
    </main>

    {{--    @elseif(in_array(request()->route()->getName(), ['register', 'register-example', 'login', 'login-example',--}}
    {{--    'forgot-password', 'forgot-password-example', 'reset-password','reset-password-example']))--}}

    {{--        {{ $slot }}--}}
    {{--        --}}{{-- Footer --}}
    {{--        @include('layouts.footer2')--}}


    {{--    @elseif(in_array(request()->route()->getName(), ['404', '500', 'lock']))--}}

    {{--        {{ $slot }}--}}


</x-layouts.base>

