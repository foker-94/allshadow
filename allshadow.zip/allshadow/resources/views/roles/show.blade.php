{{--<x-layouts.base>--}}

{{--    @extends('users.layout')--}}

{{--    @extends('layouts/sidenav')--}}





{{--</x-layouts.base>--}}

<x-layouts.base>


    {{--    @if(in_array(request()->route()->getName(), ['dashboard', 'profile', 'profile-example', 'users', 'bootstrap-tables', 'transactions',--}}
    {{--    'buttons',--}}
    {{--    'forms', 'modals', 'notifications', 'typography', 'upgrade-to-pro']))--}}

    {{-- Nav --}}
    @include('layouts.nav')
    {{-- SideNav --}}
    @include('layouts.sidenav')
    <main class="content">
        {{-- TopBar --}}
        @include('layouts.topbar')

        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> Show Users</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    {{ $user->first_name }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Prenom:</strong>
                    {{ $user->last_name }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>email:</strong>
                    {{ $user->email }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Ville:</strong>
                    {{ $user->city }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Telephone:</strong>
                    {{ $user->number }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Sexe:</strong>
                    {{ $user->gender }}
                </div>
            </div>
        </div>


        {{-- Footer --}}
        @include('layouts.footer')
    </main>

    {{--    @elseif(in_array(request()->route()->getName(), ['register', 'register-example', 'login', 'login-example',--}}
    {{--    'forgot-password', 'forgot-password-example', 'reset-password','reset-password-example']))--}}

    {{--        {{ $slot }}--}}
    {{--        --}}{{-- Footer --}}
    {{--        @include('layouts.footer2')--}}


    {{--    @elseif(in_array(request()->route()->getName(), ['404', '500', 'lock']))--}}

    {{--        {{ $slot }}--}}


</x-layouts.base>

