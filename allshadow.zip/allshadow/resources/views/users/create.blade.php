{{--<x-layouts.base>--}}

{{--    @extends('users.layout')--}}

{{--    @extends('layouts/sidenav')--}}


{{--</x-layouts.base>--}}

<x-layouts.base>


    {{--    @if(in_array(request()->route()->getName(), ['dashboard', 'profile', 'profile-example', 'users', 'bootstrap-tables', 'transactions',--}}
    {{--    'buttons',--}}
    {{--    'forms', 'modals', 'notifications', 'typography', 'upgrade-to-pro']))--}}

    {{-- Nav --}}
    @include('layouts.nav')
    {{-- SideNav --}}
    @include('layouts.sidenav')
    <main class="content">
        {{-- TopBar --}}
        @include('layouts.topbar')

        <div class="row fa-pull-left ml-4">
            <div class="row ">
            Dashbord / Create an user
            </div>
            <div class="col-md ext-center">
                <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </div>
            <div class="col-md ext-center">
                <a class="btn btn-primary btn-sm" href="{{ route('users.index') }}"> Back</a>
            </div>
        </div>

        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="container mt-5">
            <form action="{{ route('users.store') }}" method="POST">
                @csrf

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-8">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Nom:</strong>
                                    <input type="text" name="first_name" class="form-control" placeholder="Fongan kom">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Prenom:</strong>
                                    <input type="text" name="last_name" class="form-control" placeholder="Erwan">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input type="email" name="email" class="form-control" placeholder="admin@gmail.com">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Mot de pass:</strong>
                                    <input type="password" name="password" minlength="8" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Ville:</strong>
                                    <input type="text" name="city" class="form-control" placeholder="douala">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Numero de telephone:</strong>
                                    <input type="number" name="number" class="form-control" placeholder="6997822">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4">
                        <fieldset>
                            <legend>Sexe</legend>

                            <div>
                                <input type="radio" id="huey" name="gender" value="huey"
                                       checked>
                                <label for="huey">Masculin</label>
                            </div>

                            <div>
                                <input type="radio" id="dewey" name="gender" value="dewey">
                                <label for="dewey">Feminin</label>
                            </div>

                        </fieldset>
                    </div>

                </div>

            </form>
        </div>
        {{-- Footer --}}
        @include('layouts.footer')
    </main>

    {{--    @elseif(in_array(request()->route()->getName(), ['register', 'register-example', 'login', 'login-example',--}}
    {{--    'forgot-password', 'forgot-password-example', 'reset-password','reset-password-example']))--}}

    {{--        {{ $slot }}--}}
    {{--        --}}{{-- Footer --}}
    {{--        @include('layouts.footer2')--}}


    {{--    @elseif(in_array(request()->route()->getName(), ['404', '500', 'lock']))--}}

    {{--        {{ $slot }}--}}


</x-layouts.base>

