{{--<x-layouts.base>--}}

{{--    @extends('users.layout')--}}

{{--    @extends('layouts/sidenav')--}}





{{--</x-layouts.base>--}}

<x-layouts.base>


    {{--    @if(in_array(request()->route()->getName(), ['dashboard', 'profile', 'profile-example', 'users', 'bootstrap-tables', 'transactions',--}}
    {{--    'buttons',--}}
    {{--    'forms', 'modals', 'notifications', 'typography', 'upgrade-to-pro']))--}}

    {{-- Nav --}}
    @include('layouts.nav')
    {{-- SideNav --}}
    @include('layouts.sidenav')
    <main class="content">
        {{-- TopBar --}}
        @include('layouts.topbar')


        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Users</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
                </div>
            </div>
        </div>

        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('users.update',$user->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Nom:</strong>
                        <input type="text" name="first_name" value="{{ $user->first_name }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Prenom:</strong>
                        <input type="text" name="last_name" value="{{ $user->last_name }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <fieldset >
                    <legend>Select a maintenance drone:</legend>

                    <div>
                        <input type="radio" id="masculin" name="gender" value="Masculin"
                               checked>
                        <label for="masculin">Masculin</label>
                    </div>

                    <div>
                        <input type="radio" id="feminin" name="gender" value="Masculin">
                        <label for="feminin">Feminin</label>
                    </div>

                </fieldset>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>email:</strong>
                        <input type="text" name="email" value="{{ $user->email }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>password:</strong>
                        <input type="text" name="password" value="{{ $user->password }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Ville:</strong>
                        <input type="text" name="city" value="{{ $user->city }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Telephone:</strong>
                        <input type="text" name="number" value="{{ $user->number }}" class="form-control" placeholder="Name">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 mt-4 text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>

        </form>

        {{-- Footer --}}
        @include('layouts.footer')
    </main>

    {{--    @elseif(in_array(request()->route()->getName(), ['register', 'register-example', 'login', 'login-example',--}}
    {{--    'forgot-password', 'forgot-password-example', 'reset-password','reset-password-example']))--}}

    {{--        {{ $slot }}--}}
    {{--        --}}{{-- Footer --}}
    {{--        @include('layouts.footer2')--}}


    {{--    @elseif(in_array(request()->route()->getName(), ['404', '500', 'lock']))--}}

    {{--        {{ $slot }}--}}


</x-layouts.base>

