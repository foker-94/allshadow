{{--<x-layouts.base>--}}

{{--    @extends('users.layout')--}}

{{--    @extends('layouts/sidenav')--}}





{{--</x-layouts.base>--}}

<x-layouts.base>


    {{--    @if(in_array(request()->route()->getName(), ['dashboard', 'profile', 'profile-example', 'users', 'bootstrap-tables', 'transactions',--}}
    {{--    'buttons',--}}
    {{--    'forms', 'modals', 'notifications', 'typography', 'upgrade-to-pro']))--}}

    {{-- Nav --}}
    @include('layouts.nav')
    {{-- SideNav --}}
    @include('layouts.sidenav')
    <main class="content">
        {{-- TopBar --}}
        @include('layouts.topbar')

        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> Show Users</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    {{ $permission->name }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Prix:</strong>
                    {{ $permission->price }}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Description:</strong>
                    {{ $permission->description }}
                </div>
            </div>
        </div>
        <form action="{{ route('permissions.update',$permission->id) }}" method="POST">
            <input type="checkbox" name="outbid" value="Female">Activer les enchere</input>
            <div class="col-xs-12 col-sm-12 col-md-12 mt-4 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>

        <?php
        $waiting_day = 1637210196;
        $time_left = $waiting_day - time();

        $days = floor($time_left / (60*60*24));
        $time_left %= (60 * 60 * 24);

        $hours = floor($time_left / (60 * 60));
        $time_left %= (60 * 60);

        $min = floor($time_left / 60);
        $time_left %= 60;

        $sec = $time_left;

        echo "Compte a rebourd: $days jours $hours heures  $min min $sec sec restantes";
        ?>
        {{-- Footer --}}
        @include('layouts.footer')
    </main>


    {{--    @elseif(in_array(request()->route()->getName(), ['register', 'register-example', 'login', 'login-example',--}}
    {{--    'forgot-password', 'forgot-password-example', 'reset-password','reset-password-example']))--}}

    {{--        {{ $slot }}--}}
    {{--        --}}{{-- Footer --}}
    {{--        @include('layouts.footer2')--}}


    {{--    @elseif(in_array(request()->route()->getName(), ['404', '500', 'lock']))--}}

    {{--        {{ $slot }}--}}


</x-layouts.base>

