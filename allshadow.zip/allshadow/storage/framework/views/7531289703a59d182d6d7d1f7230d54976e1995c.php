











<?php if (isset($component)) { $__componentOriginald8bdefe537b868c30952851c478827a760077823 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Base::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Base::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    
    
    

    
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="content">
        
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> Show Users</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>"> Back</a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <?php echo e($permission->name); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Prix:</strong>
                    <?php echo e($permission->price); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Description:</strong>
                    <?php echo e($permission->description); ?>

                </div>
            </div>
        </div>
        <form action="<?php echo e(route('permissions.update',$permission->id)); ?>" method="POST">
            <input type="checkbox" name="outbid" value="Female">Activer les enchere</input>
            <div class="col-xs-12 col-sm-12 col-md-12 mt-4 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>

        <?php
        $waiting_day = 1637210196;
        $time_left = $waiting_day - time();

        $days = floor($time_left / (60*60*24));
        $time_left %= (60 * 60 * 24);

        $hours = floor($time_left / (60 * 60));
        $time_left %= (60 * 60);

        $min = floor($time_left / 60);
        $time_left %= 60;

        $sec = $time_left;

        echo "Compte a rebourd: $days jours $hours heures  $min min $sec sec restantes";
        ?>
        
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>


    
    

    
    
    


    

    


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8bdefe537b868c30952851c478827a760077823)): ?>
<?php $component = $__componentOriginald8bdefe537b868c30952851c478827a760077823; ?>
<?php unset($__componentOriginald8bdefe537b868c30952851c478827a760077823); ?>
<?php endif; ?>

<?php /**PATH D:\Documents\Projet\House Innovation\3NINNOV-main\resources\views/permissions/show.blade.php ENDPATH**/ ?>