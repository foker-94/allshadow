








<?php if (isset($component)) { $__componentOriginald8bdefe537b868c30952851c478827a760077823 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Base::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Base::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    
    
    

    
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('layouts.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="content">
        
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row fa-pull-left ml-4">
            <div class="row ">
            Dashbord / Create an user
            </div>
            <div class="col-md ext-center">
                <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </div>
            <div class="col-md ext-center">
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('users.index')); ?>"> Back</a>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="container mt-5">
            <form action="<?php echo e(route('users.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-8">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Nom:</strong>
                                    <input type="text" name="first_name" class="form-control" placeholder="Fongan kom">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Prenom:</strong>
                                    <input type="text" name="last_name" class="form-control" placeholder="Erwan">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input type="email" name="email" class="form-control" placeholder="admin@gmail.com">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Mot de pass:</strong>
                                    <input type="password" name="password" minlength="8" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Ville:</strong>
                                    <input type="text" name="city" class="form-control" placeholder="douala">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md">
                                <div class="form-group">
                                    <strong>Numero de telephone:</strong>
                                    <input type="number" name="number" class="form-control" placeholder="6997822">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4">
                        <fieldset>
                            <legend>Sexe</legend>

                            <div>
                                <input type="radio" id="huey" name="gender" value="huey"
                                       checked>
                                <label for="huey">Masculin</label>
                            </div>

                            <div>
                                <input type="radio" id="dewey" name="gender" value="dewey">
                                <label for="dewey">Feminin</label>
                            </div>

                        </fieldset>
                    </div>

                </div>

            </form>
        </div>
        
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    
    

    
    
    


    

    


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8bdefe537b868c30952851c478827a760077823)): ?>
<?php $component = $__componentOriginald8bdefe537b868c30952851c478827a760077823; ?>
<?php unset($__componentOriginald8bdefe537b868c30952851c478827a760077823); ?>
<?php endif; ?>

<?php /**PATH D:\Documents\Projet\House Innovation\3NINNOV-main\resources\views/users/create.blade.php ENDPATH**/ ?>